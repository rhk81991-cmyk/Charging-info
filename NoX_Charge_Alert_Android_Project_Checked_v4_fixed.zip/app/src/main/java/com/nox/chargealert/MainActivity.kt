package com.nox.chargealert

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.BroadcastReceiver
import android.os.Build
import android.os.Bundle
import android.os.BatteryManager
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var batteryText: TextView
    private lateinit var statusText: TextView
    private lateinit var speakSwitch: Switch
    private lateinit var connectedSwitch: Switch
    private lateinit var disconnectedSwitch: Switch
    private var tts: TextToSpeech? = null

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            refreshBattery()
        }
    }

    private val prefs by lazy { getSharedPreferences("settings", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        batteryText = findViewById(R.id.batteryText)
        statusText = findViewById(R.id.statusText)
        speakSwitch = findViewById(R.id.speakSwitch)
        connectedSwitch = findViewById(R.id.connectedSwitch)
        disconnectedSwitch = findViewById(R.id.disconnectedSwitch)

        speakSwitch.isChecked = prefs.getBoolean("speak", true)
        connectedSwitch.isChecked = prefs.getBoolean("connected", true)
        disconnectedSwitch.isChecked = prefs.getBoolean("disconnected", true)

        speakSwitch.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("speak", v).apply() }
        connectedSwitch.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("connected", v).apply() }
        disconnectedSwitch.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("disconnected", v).apply() }

        findViewById<Button>(R.id.testConnected).setOnClickListener {
            val p = currentBatteryPercent()
            EventHandler.handle(this, PowerReceiver.EVENT_CONNECTED, p)
        }
        findViewById<Button>(R.id.testDisconnected).setOnClickListener {
            val p = currentBatteryPercent()
            EventHandler.handle(this, PowerReceiver.EVENT_DISCONNECTED, p)
        }

        initTts()
        requestNotificationPermission()
        refreshBattery()
    }

    override fun onResume() {
        super.onResume()
        refreshBattery()
        ContextCompat.registerReceiver(
            this,
            batteryReceiver,
            android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onPause() {
        unregisterReceiver(batteryReceiver)
        super.onPause()
    }

    private fun initTts() {
        tts = TextToSpeech(this) { result ->
            if (result == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
            }
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        }
    }

    private fun currentBatteryPercent(): Int {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(0, 100)
    }

    private fun refreshBattery() {
        val intent = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0) (level * 100 / scale.coerceAtLeast(1)) else currentBatteryPercent()
        val plugged = (intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        batteryText.text = "$pct%"
        statusText.text = if (plugged) "⚡ Charging" else "○ Not charging"
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
