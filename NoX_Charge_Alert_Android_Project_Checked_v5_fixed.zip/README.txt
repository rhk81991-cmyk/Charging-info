NoX Charge Alert - checked Android project

What it does:
- Detects charging connected/disconnected using Android power broadcasts.
- Plays fixed connected/disconnected chimes.
- Reads the CURRENT battery percentage for each event.
- Shows a notification with the live percentage.
- Optional text-to-speech says the live percentage.
- Settings are saved locally.
- Test buttons use the current battery percentage.

Important:
This project was statically checked in this environment (XML parsing, archive integrity,
source structure/references, and Kotlin source balance checks). A full Android Gradle build
was not run here because an Android SDK/Gradle environment is not installed in this runtime.
GitHub Actions is configured to perform the real build.

Phone-only GitHub method:
1. Create an EMPTY GitHub repository.
2. Upload this ZIP file to the repository root. Do not extract it on GitHub.
3. From the repository ROOT, create the workflow file at exactly:
   .github/workflows/build-apk.yml
4. Paste the workflow supplied with this project.
5. Commit to main. GitHub Actions will extract the ZIP and build the APK.

The project ZIP filename is:
NoX_Charge_Alert_Android_Project_Checked_v4.zip


V5 background-sound fix:
- Charging connected/disconnected alerts now use separate Android notification channels.
- Each channel has its own fixed WAV sound, allowing the chime to work while the app is backgrounded or the screen is off.
- The previous direct MediaPlayer background playback path was removed.
- If notification permission is disabled or a channel is manually silenced in Android settings, the alert sound cannot play.
