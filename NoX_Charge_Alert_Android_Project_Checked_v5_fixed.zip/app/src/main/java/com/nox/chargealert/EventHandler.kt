package com.nox.chargealert

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import java.util.Locale

object EventHandler {
    private const val CHANNEL_CONNECTED = "charge_connected"
    private const val CHANNEL_DISCONNECTED = "charge_disconnected"

    private var tts: TextToSpeech? = null
    private var ttsReady = false

    fun handle(
        context: Context,
        event: String,
        percent: Int,
        onFinished: (() -> Unit)? = null
    ) {
        val appContext = context.applicationContext
        val prefs = appContext.getSharedPreferences("settings", Context.MODE_PRIVATE)
        val enabled = if (event == PowerReceiver.EVENT_CONNECTED) {
            prefs.getBoolean("connected", true)
        } else {
            prefs.getBoolean("disconnected", true)
        }

        if (!enabled) {
            onFinished?.invoke()
            return
        }

        ensureChannels(appContext)

        val connected = event == PowerReceiver.EVENT_CONNECTED
        val title = if (connected) {
            "Charging connected"
        } else {
            "Charging disconnected"
        }
        val channelId = if (connected) CHANNEL_CONNECTED else CHANNEL_DISCONNECTED

        // The notification channel owns the fixed chime. This is reliable when
        // the app is in the background or the screen is off.
        val notification = NotificationCompat.Builder(appContext, channelId)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle(title)
            .setContentText("Battery $percent%")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .build()

        val nm = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(if (connected) 101 else 102, notification)

        if (prefs.getBoolean("speak", true)) {
            speakLivePercent(appContext, event, percent)
        }

        // NotificationManager has accepted the notification request.
        onFinished?.invoke()
    }

    @Synchronized
    private fun speakLivePercent(context: Context, event: String, percent: Int) {
        val text = if (event == PowerReceiver.EVENT_CONNECTED) {
            "Charging connected. Battery $percent percent."
        } else {
            "Charging disconnected. Battery $percent percent."
        }

        if (tts == null) {
            ttsReady = false
            tts = TextToSpeech(context) { result ->
                if (result == TextToSpeech.SUCCESS) {
                    tts?.language = Locale.US
                    ttsReady = true
                    tts?.speak(
                        text,
                        TextToSpeech.QUEUE_FLUSH,
                        null,
                        "nox_${event}_${System.currentTimeMillis()}"
                    )
                }
            }
            return
        }

        if (ttsReady) {
            tts?.speak(
                text,
                TextToSpeech.QUEUE_FLUSH,
                null,
                "nox_${event}_${System.currentTimeMillis()}"
            )
        }
    }

    private fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < 26) return

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        createChannel(
            nm,
            CHANNEL_CONNECTED,
            "Charging connected",
            R.raw.connected,
            attrs
        )
        createChannel(
            nm,
            CHANNEL_DISCONNECTED,
            "Charging disconnected",
            R.raw.disconnected,
            attrs
        )
    }

    private fun createChannel(
        nm: NotificationManager,
        id: String,
        name: String,
        soundRes: Int,
        attrs: AudioAttributes
    ) {
        if (nm.getNotificationChannel(id) != null) return

        val soundUri = Uri.parse("android.resource://${BuildConfig.APPLICATION_ID}/$soundRes")
        val channel = NotificationChannel(id, name, NotificationManager.IMPORTANCE_HIGH).apply {
            description = "NoX charging alert sound"
            setSound(soundUri, attrs)
            enableVibration(false)
        }
        nm.createNotificationChannel(channel)
    }
}
